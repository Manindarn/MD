<?php
require_once 'HelperFunctions.php';
require_once 'define.php';
require_once 'types/User.php';

require_once DB_PATH . 'MySqlDB.php';
require_once DB_PATH . 'MongoDB.php';

class DEInterface {
    public $error=[];
    use HelperFunctions;
    private $dashboardData = [];
    private $userUserDetailsObject = null;
    private $mongoOrgObject = null;
    private $portConfig = null;
    private $mongoBatchObject = null;
    private $mongoUserProductObject = null;
    private $mongoGroupsObject = null;
    private $mongoSectionObject = null;
    private $mongoPSBObject = null;
    private $result = null;
    private $upgradeConfig = null;
    private $mongoOrderObject = null;
    private $mysqlOrderMasterObject = null;
    private $mongoUpdatedData = [];
    private $log = [];
    
    public function __construct()
    {
        $this->portConfig = $this->getConfig('porting');
        $this->upgradeConfig = $this->getConfig('class_upgrade');
        $this->defaultMathPID = $this->portConfig['defaultMathPID'];
        $this->defaultEnglighPID = $this->portConfig['defaultEnglighPID'];
        $this->mongoOrgObject = new MongoDB('Organizations');
        $this->mongoBatchObject = new MongoDB('Batch');
    }  

	public function getLikeOrganizations($keyword = null){
		
        $apiResponse = $this->executeCurl(LOC_FRAMEWORK_BASE_URL . 'Mindspark/UserManagement/GetAllOrganizations');
       // echo"<pre>";print_r($apiResponse);//die;
        $this->dashboardData['orgList'] = isset($apiResponse['data']) ? $apiResponse['data'] : [];
        return $this->dashboardData;
    }

    public function getOrgBatches($orgIds = []){
        
        $resultArray = array();
        if(count($orgIds) > 0){

           foreach($orgIds as $orgID){

                $orgBatchResult= $this->mongoBatchObject->findAll(["orgID" => $orgID]);

                //var_dump($orgBatchResult);

             array_push($resultArray, $orgBatchResult);

            }
        }
           
        return $orgBatchResult;
    }

   
    
    public function executeCurl($url, $data = [])
    {
        $headers = ['Auth:EISecret'];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1); //0 for a get request
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $curlResponse = curl_exec($ch);

        return json_decode($curlResponse, true);
    }

}
	
?>

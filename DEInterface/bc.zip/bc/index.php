<?php
require_once 'define.php';
require_once('DEInterface.php');

session_start();

if ($logout = $_GET['logout']??false) {
    $_SESSION['loggedID'] = false;
}

if (!empty($_POST)) {
    if ($accessCode = $_POST['accessCode']??false) {

        if ($accessCode == ACCESS_CODE) {
            $_SESSION['loggedID'] = true;
        } else {
            die("Invalid access code");
        }

    } else {
        die("Please enter access code.");
    }
}

$deInterfaceObj = new DEInterface();
$orgList = $deInterfaceObj->getLikeOrganizations();

//var_dump($orgList);

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>DEInterface</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.jquery.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.4.2/chosen.min.css">
	<style>
		.chosen-container {
			width:100% !important;
		}
		.chosen-container-multi .chosen-choices li.search-choice{
			margin: 5px 5px 3px 0 !important;
		}
		.chosen-choices li.search-field input[type=text] {
	   		height: 31px !important;
		}
		.chosen-container-active.chosen-with-drop .chosen-single div b {
   			 background-position: -18px 6px !important;
		}
		.chosen-container-single .chosen-single {
   			padding: 4px 0 0 8px !important;
			height: 34px !important;
		}
		.error{
			color:red;
			display:block;
		}
		.lbl-block {
   			 display: block;
		}
	</style>
</head>
<body>
	<div class="container">
		<br/><br/>
		<?php if ($_SESSION['loggedID']??false) { ?>
			<form class="form-data-extraction" method="post" action="">
				<div class="row">
					<div class="col-md-3 col-md-offset-3" >
						<div class="form-group">
							<label class="lbl-block">Academic Year</label>
							<select data-placeholder="Academic Year" class="chosen-select"  tabindex="4" name="batch" id="batch">

							</select>
						  
						</div>
					</div>
					<div class="col-md-4">
						<div class="form-group">
							<label class="lbl-block">School Code</label>
							<select data-placeholder="School Code" class="chosen-select" multiple  tabindex="4" name="schoolCode" id="schoolCode">
							<?php 
								foreach($orgList['orgList'] as $key => $val ){
									
									echo '<option value="'.$val['orgID'].'">'.$val['name'].'</option>';
								}
							?>
							</select>  
							<span class="max-option-select-error error"></span>
						</div>
					</div>
					<div class="col-md-12 text-center">
						<br/><br/>
						<div class="form-group">
							<label class="lbl-block">Do you want to select specific Class or All ?</label>
							<label class="checkbox-inline">
								<input type="radio" name="isSpecificDataSelected" value="Specific"> Specific
							</label>
							<label class="checkbox-inline">
								<input type="radio" name="isSpecificDataSelected" value="All"> All
							</label>
						</div>
					</div>


				</div>
				<div class="row class-section-row hide">
					<div class="col-md-2 col-md-offset-4">
						<div class="form-group">
							<label class="lbl-block">Class</label>
							<select data-placeholder="Select Class" class="chosen-select" multiple style="width:100%;" tabindex="4">
								<option value=""></option>
								<option value="I">I</option>
								<option value="II">II</option>
								<option value="III">III</option>
								<option value="IV">IV</option>
								<option value="V">V</option>
								<option value="VI">VI</option>
								<option value="VII">VII</option>
							</select>  
						</div>
					</div>
					<div class="col-md-2">
						<div class="form-group">
							<label class="lbl-block">Section</label>
							<select data-placeholder="Select Section" class="chosen-select" multiple style="width:100%;" tabindex="4">
								<option value=""></option>
								<option value="A"> A</option>
								<option value="B">B</option>
								<option value="C">C</option>
								<option value="D">D</option>
							</select>  
						</div>
					</div>
				</div>

				
				<hr/>
				<div class="row">
					<br/><br/>
					<div class="col-md-12 text-center">
						<div class="form-group">
							<label class="lbl-block">Do you want to select specific student in this ?</label>
							<label class="checkbox-inline">
								<input type="radio" name="isSpecificStudSelected" value="Specific"> Specific
							</label>
							<label class="checkbox-inline">
								<input type="radio" name="isSpecificStudSelected" value="All"> All
							</label>
						</div>
					</div>
					
						
					<div class="col-md-3 col-md-offset-3 div-student hide">
						<div class="form-group">
							<label class="lbl-block">Student Name</label>
							<input type="text" class="form-control" name="studentName" id="studentName" placeholder="Student Name">
						</div>
					</div>
					<div class="col-md-2 div-start-date col-md-offset-4">
						<div class="form-group">
							<label class="lbl-block">Start Date</label>
							<input type="date" class="form-control" name="startDate" id="startDate" placeholder="Start Date">
						</div>
					</div>
					<div class="col-md-2">
						<div class="form-group">
							<label class="lbl-block">End Date</label>
							<input type="date" class="form-control" name="endDate" id="endDate" placeholder="End Date">
						</div>
					</div>
					<div class="col-md-12 text-center">
						<br/><br/>
						<div class="form-group">
							<button type="submit" class="btn btn-success" name="btnSubmit" id="btnSubmit">Submit</button>
						</div>
					</div>
				</div>
			</form>
		<?php } 
		else { ?>
        <div class="col-md-4 col-md-offset-3" style="margin-top: 50px;">
            <form class="form-horizontal" accept="/" method="post">
                <div class="form-group">
                    <label for="accessCode" class="col-md-4 control-label">Access Code</label>
                    <div class="col-md-8">
                        <input type="password" required="" name="accessCode" class="form-control" id="accessCode"
                               placeholder="Access code">
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-offset-6 col-md-8">
                        <button type="submit" class="btn btn-default">Sign in</button>
                    </div>
                </div>
            </form>
        </div>
    <?php } ?>
	</div>
	<script type="text/javascript">
		var config = {
			'.chosen-select'           : {max_selected_options:2},
			'.chosen-select-deselect'  : {allow_single_deselect:true},
			'.chosen-select-no-single' : {disable_search_threshold:10},
			'.chosen-select-no-single' : {disable_search_threshold:10},
			'.chosen-select-no-results': {no_results_text:'Oops, nothing found!'},
			'.chosen-select-width'     : {width:"95%"}
		}
		for (var selector in config) {
			$(selector).chosen(config[selector]);
		}
	</script>
	<script>

		$(document).ready(function(){
			$('.chosen-select').chosen({}).change( function(obj, result) {
				console.debug("changed: %o", arguments);
				
				console.log("selected: " + result.selected);
			});
			$(".chosen-select").bind("chosen:maxselected", function () {
						
				$('.max-option-select-error').html('You can select only two school code');
				
					setTimeout(function(){ 
						$('.max-option-select-error').html('');
												
					}, 4000);
			}); 
			
			$('#schoolCode').change(function(){
				$('#batch').empty();
				$('#batch').trigger("chosen:updated");	
				var schoolCodes = $(this).val();
				console.log($(this).val());
				$.ajax({
					url:'getSchoolAcademicYear.php',
					type:'post',
					data:{'orgID': schoolCodes, 'action':'getOrgBatches' },
					success:function(result){
						console.log(result);
						var response = JSON.parse(result);
						for (var i=0; i<response.length;i++){
							//alert(response[i]['name'])
							var found = 0;
							$('#batch').find('option').each(function() {
								if($(this).val() == response[i]['name']) found = 1;
							});

							if(found == 0)
								$('#batch').append($('<option>', { value: response[i]['name'], text : response[i]['name'] }));	
						}
						
						$('#batch').trigger("chosen:updated");	
					}
				});
			})

			$('input[name="isSpecificDataSelected"]').click(function(){

				alert($(this).val());
				if($(this).val() == "Specific"){
					$('.class-section-row').show().removeClass('hide');
				}else{
					$('.class-section-row').hide();
				}
			});

			$('input[name="isSpecificStudSelected"]').click(function(){

				alert($(this).val());
				if($(this).val() == "Specific"){
					$('.div-student').show().removeClass('hide');
					$('.div-start-date').removeClass('col-md-offset-4')
				}else{
					$('.div-student').hide();
					$('.div-start-date').addClass('col-md-offset-4')
				}
			});

		});
	</script>
</body>
</html>
